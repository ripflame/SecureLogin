<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="../css/custom.css" rel="stylesheet" media="screen">
    <title>Contact</title>
</head>
<body>
	<?php include '../layouts/header.php'; ?>
 	<div class="container">
 		<h1>Contact</h1>
 		<p>
 			Contact me at: <a href="mailto:ripflame@gmail.com">ripflame@gmail.com</a>
 		</p>
 		<?php include '../layouts/footer.php'; ?>
 	</div>
</body>
</html>
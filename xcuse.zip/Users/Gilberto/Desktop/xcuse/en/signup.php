<?php
    include("../includes/config.php");

    if($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = $db->real_escape_string($_POST["name"]);
        $email = $db->real_escape_string($_POST["email"]);
        $password = $db->real_escape_string($_POST["password"]);
        $password_confirmation = $db->real_escape_string($_POST["password_confirmation"]);

        if($password == $password_confirmation) {
            $password = crypt($password);
            $sql = "INSERT INTO `users` (`name`, `email`, `password`) VALUES ('$username', '$email', '$password')";
            if ($db->query($sql)) {
                session_start();
                $_SESSION["user_name"] = $username;
                $_SESSION["user_email"] = $email;
                header("Location: home.php");
                exit();
            } else {
                $error = $db->error;
                echo $error;
            }
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="../css/custom.css" rel="stylesheet" media="screen">
    <title> signup </title>
</head>
<body>
    <?php include("../layouts/header.php") ?>

    <div class="container">
        <h1>Sign up</h1>

        <div class="row">
            <div class="span6 offset3">
                <form action="" method="post">
                    <label for="user_name">Name</label>
                    <input id="user_name" name="name" size="30" type="text" required/>

                    <label for="user_email">Email</label>
                    <input id="user_email" name="email" size="30" type="text" pattern="[\w+\-.]+@[a-z\d\-.]+\.[a-z]+" required/>

                    <label for="user_password">Password</label>
                    <input id="user_password" name="password" size="30" type="password" required/>

                    <label for="user_password_confirmation">Confirmation</label>
                    <input id="user_password_confirmation" name="password_confirmation" size="30" type="password" required/>

                    <input class="btn btn-large btn-primary" name="commit" type="submit" value="Create my account" />
                </form>
            </div>
        </div>
        <?php include '../layouts/footer.php'; ?>
    </div>
</body>
</html>

<?php
    $db_hostname = "localhost";
    $db_user = "xcuseusr";
    $db_password = "xcuse!@#123";
    $db_name = "xcusedb";

    $db = new mysqli($db_hostname, $db_user, $db_password, $db_name);
    $db->set_charset('utf8');
?>

<?php
    include("config.php");
    session_start();
    if(!$_SESSION['user_email']) {
    	header("Location: ../en/login.php");
    }
?>

<header class="navbar navbar-fixed-top navbar-inverse">
    <div class="navbar-inner">
        <div class="container">
            <a href="../en/home.php" id="logo">Xcuse Tracker</a>
            <nav>
                <ul class="nav pull-right">
                    <li><a href="../en/home.php">Home</a></li>
                    <?php if(isset($_SESSION['user_email'])): ?>
                    <li><a href='../en/profile.php'>Profile</a></li>
                    <li><a href='../includes/logout.php'>Logout</a></li>
                    <?php else: ?>
                    <li><a href='../en/login.php'>Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</header>

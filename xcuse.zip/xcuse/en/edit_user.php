<?php
include("../includes/lock.php");
include("../includes/config.php");

if($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_name = $db->real_escape_string($_POST["name"]);
    $user_email = $db->real_escape_string($_POST["email"]);

    $sql = "UPDATE `users` SET `name`='".$user_name."', `email`='".$user_email."' WHERE `name`='".$_SESSION['user_name']."' AND `email`='".$_SESSION['user_email']."'";
    if ($db->query($sql)) {
        $_SESSION['user_name'] = $user_name;
        $_SESSION['user_email'] = $user_email;
        header("Location: profile.php");
    } else {
        echo "Couldn't save. Error: ".$db->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="../css/custom.css" rel="stylesheet" media="screen">
</head>
<body>
    <?php include '../layouts/header.php'; ?>
    <div class="container">

        <div class="row">
            <div class="span6 offset3">
                <form action="" method="post">
                    <label for="user_name">Name</label>
                    <input id="user_name" name="name" size="30" type="text"
                        value="<?php echo $_SESSION['user_name'] ?>" required/>

                    <label for="user_email">Email</label>
                    <input id="user_email" name="email" size="30" type="text"
                        pattern="[\w+\-.]+@[a-z\d\-.]+\.[a-z]+"
                        value="<?php echo $_SESSION['user_email'] ?>" required/>

                    <input class="btn btn-large btn-primary" name="commit" type="submit" value="Save changes" />
                </form>
            </div>
        </div>

        <?php include '../layouts/footer.php'; ?>
    </div>
</body>
</html>

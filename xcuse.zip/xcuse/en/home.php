<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="../css/custom.css" rel="stylesheet" media="screen">
</head>
<body>
    <?php include '../layouts/header.php'; ?>
    <div class="container">

        <div class="center hero-unit">

            <? if(isset($_SESSION['user_name'])): ?>
            <h2>Welcome <? echo $_SESSION['user_name']; ?></h2>
            <div class="row">
                <div class="span6 offset2">
                    Here you can manage your excuses, have fun and keep your lies straight.
                </div>
            </div>
            <div class="row">
                <a class="btn btn-small" href="">See your excuses</a>
                <a class="btn btn-small" href="">Create an excuse</a>
                <!-- <a class="btn btn-small" href="">Other button</a> -->
            </div>
            <? else: ?>
            <h1>Welcome</h1>
            <p>
                The Xcuse Tracker is a platform that helps you keep up with your latest excuses<br>
                because we know how important it is to keep your lies straight.
            </p>
            <a class="btn btn-large btn-primary" href="/en/signup.php">Sign up!</a>
            <? endif; ?>
        </div>

        <?php include '../layouts/footer.php'; ?>
    </div>
</body>
</html>

<?php
include("../includes/config.php");
if($_SERVER["REQUEST_METHOD"] == "POST") {
	$email = $db->real_escape_string($_POST["user_email"]);
	$password = $db->real_escape_string($_POST["user_password"]);

	$sql = "SELECT * FROM `users` WHERE email='$email'";
	$result = $db->query($sql);
	if($result->num_rows == 1) {
		$row = 	$result->fetch_assoc();
		if(crypt($password, $row["password"]) == $row["password"]) {
			session_start();
			$_SESSION["user_name"] = $row["name"];
			$_SESSION["user_email"] = $email;
			header("Location: home.php");
			exit();
		} else {
			echo "Invalid password.";
		}
	} else {
		echo "Invaid user.";
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="../css/custom.css" rel="stylesheet" media="screen">
    <title>Login</title>
</head>
<body>
<?php include '../layouts/header.php'; ?>
<div class="container">
	<h1>Login</h1>

	<div class="row">
		<div class="span6 offset3">
			<form action="" method="post">
				<label for="user_email">Email</label>
				<input id="user_email" name="user_email" size="30" type="text" required />
				<label for="user_password">Password</label>
				<input id="user_password" name="user_password" size="30" type="password" required />
				<input class="btn btn-large btn-primary" name="submit" type="submit" value="Login" />
			</form>
		</div>
	</div>

	<?php include "../layouts/footer.php"; ?>
</div>
</body>
</html>
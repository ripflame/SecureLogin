<?php
include("../includes/lock.php");
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="../css/custom.css" rel="stylesheet" media="screen">
</head>
<body>
    <?php include '../layouts/header.php'; ?>
    <div class="container">

        <div class="center hero-unit">
            <div class="row">
            	<div class="span1">
            	<a class="btn btn-large" href="/en/edit_user.php"> Edit profile </a>
            	</div>
            	<h1><?php echo $_SESSION['user_name']; ?></h1>
            </div>
        </div>

        <?php include '../layouts/footer.php'; ?>
    </div>
</body>
</html>

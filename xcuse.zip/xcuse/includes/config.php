<?php 
    $db_hostname = "localhost";
    $db_user = "root";
    $db_password = "root";
    $db_name = "xcusedb";
    
    $db = new mysqli($db_hostname, $db_user, $db_password, $db_name);
    $db->set_charset('utf8');
?>
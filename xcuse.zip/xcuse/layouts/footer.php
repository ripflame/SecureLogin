<footer class="footer">
    <small>
        <a href="/en/home.php">Xcuse Tracker</a> 
        by Gilberto León
    </small>
    <nav>
        <ul>
            <li><a href="/en/contact.php">Contact</a></li>
        </ul>
    </nav>
</footer>